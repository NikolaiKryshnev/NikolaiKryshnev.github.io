// Функция поддержки формата webp
@@include('webpformat.js')


// npm i jquery
@@include("../../node_modules/jquery/dist/jquery.min.js")
// npm i slick-carousel
@@include('../../node_modules/slick-carousel/slick/slick.min.js')


// moduls
@@include('menu.js')
@@include('slick-moduls.js')
@@include('tabs.js')
// @@include('starts.js')
@@include('number.js')
@@include('sidebar.js')









